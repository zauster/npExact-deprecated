
## library(profr)

## set.seed(123)
## high <- rnorm(50) + 2
## low <- rnorm(50)

## ## npStochin
## profr(npStochinUnpaired(high, low, alternative = "two.sided"))
