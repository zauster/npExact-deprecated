library(testthat)
library(npExact)

test_check("npExact")
